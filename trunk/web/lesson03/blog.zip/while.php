<pre style="color:blue">
<?php

$a=1;
while ($a<=10)
{
  echo $a . "\n";
  $a+=1;
  if ($a==7)
    break;
}

