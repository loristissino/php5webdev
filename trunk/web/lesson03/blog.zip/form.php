<pre>
<?php

print_r($_SERVER);

?>
</pre>
<form method="POST" action="form.php">
<input type="submit">
</form>


<hr />

<a href="form.php/cancella/12">cancella</a>