<hr />
<p><a href="?action=list">Elenco articoli</a></p>
